package com.futogen.natureharvest;

import android.content.Intent;
import android.media.MediaCodec;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kotlin.text.Regex;

public class upiActivity extends AppCompatActivity {

    TextInputEditText upiIdET;
    Button proceed;

    ImageView arrow5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_upi);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        upiIdET=(TextInputEditText) findViewById(R.id.editrname);
        proceed=(Button) findViewById(R.id.upi_proceed);

        proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(upiIdET.getText().toString().isEmpty())
                {
                    Toast.makeText(upiActivity.this, "UPI ID is Missing", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Pattern upiPatt = Pattern.compile("^[0-9A-Za-z.-]{2,256}@[A-Za-z]{2,64}$");

                    Matcher matcher = upiPatt.matcher(upiIdET.getText().toString());
                    if(matcher.matches())
                    {
                        Toast.makeText(upiActivity.this, "UPI ID Verified!", Toast.LENGTH_SHORT).show();
                        Intent i1=new Intent(upiActivity.this,ProceedUpiActivity.class);
                        startActivity(i1);
                    }
                    else {
                        Toast.makeText(upiActivity.this, "Invalid UPI ID", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        arrow5=(ImageView) findViewById(R.id.arrow5);

        arrow5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(upiActivity.this,ProceedUpiActivity.class);
                startActivity(it);
                finish();
            }
        });

    }
}