package com.futogen.natureharvest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class VerifyOtpActivity extends AppCompatActivity {
    Button verifyotpbutton;
    EditText otp;
    ImageView arrow8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_verify_otp);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        otp=(EditText) findViewById(R.id.otpET);
        verifyotpbutton=(Button) findViewById(R.id.verifyOTPBtn);

        verifyotpbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String otpValue=otp.getText().toString();
                if(otpValue.isEmpty()||otpValue.length()==0)
                {
                    Toast.makeText(VerifyOtpActivity.this, "Kindly Enter OTP", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    finish();
                    Intent i = new Intent(VerifyOtpActivity.this,MainActivity.class);
                    startActivity(i);
                }
            }
        });

        arrow8=(ImageView) findViewById(R.id.arrow8);

        arrow8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(VerifyOtpActivity.this,MainActivity.class);
                startActivity(it);
                finish();
            }
        });
    }
}