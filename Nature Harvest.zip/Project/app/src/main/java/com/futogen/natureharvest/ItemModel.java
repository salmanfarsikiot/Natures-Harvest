package com.futogen.natureharvest;

public class ItemModel
{
    private int ItemId;
    private String ItemName;
    private int ItemImage;
    private String ItemDescription;
    private String ItemUOM;
    private String Price;
    private String Nums;

    public ItemModel(int ItemId,String ItemName,int ItemImage,String ItemDescription, String ItemUOM, String Price, String Nums)
    {
        this.ItemId=ItemId;
        this.ItemName=ItemName;
        this.ItemImage=ItemImage;
        this.ItemDescription=ItemDescription;
        this.ItemUOM=ItemUOM;
        this.Price=Price;
        this.Nums=Nums;
    }

    public int getItemId() {
        return ItemId;
    }

    public void setItemId(int itemId) {
        ItemId = itemId;
    }

    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String itemName) {
        ItemName = itemName;
    }

    public int getItemImage() {
        return ItemImage;
    }

    public void setItemImage(int itemImage) {
        ItemImage = itemImage;
    }

    public String getItemDescription() {
        return ItemDescription;
    }

    public void setItemDescription(String itemDescription) {
        ItemDescription = itemDescription;
    }

    public String getItemUOM() {
        return ItemUOM;
    }

    public void setItemUOM(String itemUOM) {
        ItemUOM = itemUOM;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    public String getNums() {
        return Nums;
    }

    public void setNums(String nums) {
        Nums = nums;
    }
}
