package com.futogen.natureharvest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ForgetPaswordActivity extends AppCompatActivity {
    EditText username;
    Button sendOTP;
    ImageView arrow2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forget_pasword);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        username=(EditText) findViewById(R.id.unameET);
        sendOTP=(Button) findViewById(R.id.sendOTPBtn);

        sendOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userNameInput=username.getText().toString();
                if(userNameInput.isEmpty())
                {
                    Toast.makeText(ForgetPaswordActivity.this, "Username is Missing", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Intent i = new Intent(ForgetPaswordActivity.this,VerifyOtpActivity.class);
                    startActivity(i);
                }
            }
        });
        arrow2=(ImageView) findViewById(R.id.arrow2);

        arrow2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(ForgetPaswordActivity.this,SignupActivity.class);
                startActivity(it);
                finish();
            }
        });
    }
}