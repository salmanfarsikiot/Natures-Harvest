package com.futogen.natureharvest;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ActivityPaymentSummary extends AppCompatActivity {
    ImageView arrow4;
LinearLayout cu1,cu2;
TextView orderPrice,taxPrice,deliveryPrice,totalPrice,itemName;


AlertDialog.Builder builder;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_payment_summary);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        cu1=findViewById(R.id.upi);
        cu2=findViewById(R.id.cod1);

        itemName=(TextView)findViewById(R.id.itemNameTV);
        orderPrice=(TextView)findViewById(R.id.orderPriceTV);
        taxPrice=(TextView)findViewById(R.id.taxPriceTV);
        deliveryPrice=(TextView)findViewById(R.id.deliveryPriceTV);
        totalPrice=(TextView)findViewById(R.id.totalPriceTV);

        cu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ps1 = new Intent(ActivityPaymentSummary.this,upiActivity.class);
                startActivity(ps1);
            }
        });
        cu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder = new AlertDialog.Builder(ActivityPaymentSummary.this);

                //builder.setMessage("Message") .setTitle("You have meeting at 02:00 PM");
                builder.setMessage("Are you sure want to place this order?").setCancelable(false)
                        .setPositiveButton("PLACE ORDER", new DialogInterface.OnClickListener()
                        {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent ps1 = new Intent(ActivityPaymentSummary.this,CashOndeliveryDoneActivity.class);
                                startActivity(ps1);
                            }
                        })
                        .setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(ActivityPaymentSummary.this, "Request Cancelled", Toast.LENGTH_SHORT).show();
                            }
                        });
                AlertDialog alert=builder.create();
                alert.setTitle("Sample");
                alert.show();
            }
        });

        arrow4=(ImageView) findViewById(R.id.arrow4);

        arrow4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(ActivityPaymentSummary.this,OneProductViewActivity.class);
                startActivity(it);
                finish();
         }
});



        SharedPreferences sh = getSharedPreferences("itemDetail", Context.MODE_PRIVATE);

        String itmName = sh.getString("ItemName","");
        String itmPrice = sh.getString("ItemPrice","");

        double price= Double.parseDouble(itmPrice);

        double tax = (price*10)/100;
        taxPrice.setText(String.valueOf(tax));

        double delivery = 100.00;
        deliveryPrice.setText(String.valueOf(delivery));

        double total = price+tax+delivery;
        totalPrice.setText(String.valueOf(total));

        itemName.setText(itmName);
        orderPrice.setText(itmPrice);

        arrow4=(ImageView) findViewById(R.id.arrow4);

        arrow4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(ActivityPaymentSummary.this,OneProductViewActivity.class);
                startActivity(it);
                finish();
            }
        });




    }
}