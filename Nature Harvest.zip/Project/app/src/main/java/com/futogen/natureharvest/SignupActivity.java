package com.futogen.natureharvest;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SignupActivity extends AppCompatActivity {
    Button b1;
    ImageView arrow1;

    FirebaseAuth mAuth;

    EditText fullName, email, mobileNum,address,landmark,password,cnfPass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        b1=findViewById(R.id.signUp);

        fullName=(EditText) findViewById(R.id.fullnameET);
        email=(EditText)findViewById(R.id.emailET);
        mobileNum=(EditText) findViewById(R.id.mobilenumberET);
        address=(EditText) findViewById(R.id.addressET);
        landmark=(EditText) findViewById(R.id.cityET);
        password=(EditText) findViewById(R.id.passET);
        cnfPass=(EditText) findViewById(R.id.confpasswordET);

        Toast.makeText(this, "REGISTER HERE!", Toast.LENGTH_SHORT).show();

        mAuth = FirebaseAuth.getInstance();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fullName.getText().toString().isEmpty() ||
                        email.getText().toString().isEmpty() ||
                        mobileNum.getText().toString().isEmpty() ||
                        address.getText().toString().isEmpty() ||
                        landmark.getText().toString().isEmpty() ||
                        password.getText().toString().isEmpty() ||
                        cnfPass.getText().toString().isEmpty()) {

                    Toast.makeText(SignupActivity.this, "Fill all the fields and Try Again!", Toast.LENGTH_SHORT).show();
                } else {
                    String emailText = email.getText().toString(); // Extract text from EditText
                    String passwordText = password.getText().toString(); // Extract text from EditText

                    if (TextUtils.isEmpty(emailText))
                    {
                        Toast.makeText(getApplicationContext(),
                                        "Please enter email!!",
                                        Toast.LENGTH_LONG)
                                .show();
                        return;
                    }
                    if (TextUtils.isEmpty(passwordText))
                    {
                        Toast.makeText(getApplicationContext(),
                                        "Please enter password!!",
                                        Toast.LENGTH_LONG)
                                .show();
                        return;
                    }
                    mAuth.createUserWithEmailAndPassword(emailText, passwordText)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>()
                            {

                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task)
                                {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(getApplicationContext(),
                                                        "Registration successful!",
                                                        Toast.LENGTH_LONG)
                                                .show();
                                        Intent intent
                                                = new Intent(SignupActivity.this,
                                                MainActivity.class);
                                        startActivity(intent);
                                    }
                                    else
                                    {
                                        Toast.makeText(
                                                        getApplicationContext(),
                                                        "Registration failed!!"
                                                                + " Please try again later",
                                                        Toast.LENGTH_LONG)
                                                .show();
                                    }
                                }
                            });
                }
            }
        });

        arrow1=(ImageView) findViewById(R.id.arrow1);

        arrow1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(SignupActivity.this,MainActivity.class);
                startActivity(it);
                finish();
            }
        });

    }
}