package com.futogen.natureharvest;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class OneProductViewActivity extends AppCompatActivity {
    ImageView arrow3;


    Button buy_now;
    ImageView itmImage;
    TextView itmName,itmDesc,itmPrice,itmNums;
    ArrayList<ItemModel> itemsList;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_one_product_view);

        buy_now = (Button) findViewById(R.id.buy_now);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        itmImage=(ImageView)findViewById(R.id.itemImg);
        itmName=(TextView)findViewById(R.id.itemName);
        itmDesc=(TextView)findViewById(R.id.itemDesc);
        itmPrice=(TextView)findViewById(R.id.itemPrice);
        itmNums=(TextView)findViewById(R.id.itemNums);

        itemsList=new ArrayList<ItemModel>();
        itemsList.add(new ItemModel(1,"Badam",R.drawable.badham,"Badam (almonds) are rich in healthy fats, vitamins, and minerals, promoting brain health, heart health, and improving skin quality. They also aid in weight management and boost energy levels.","1KG","500","\"5\" Nums"));
        itemsList.add(new ItemModel(2,"Pista",R.drawable.pista,"Pistachios are rich in antioxidants, healthy fats, and fiber, promoting heart health and digestion. They also support weight management and improve skin health due to their high vitamin and mineral content.","1KG","1000","\"3\" Nums"));
        itemsList.add(new ItemModel(3,"Cashew",R.drawable.cashew,"Cashews are rich in healthy fats, protein, and antioxidants, supporting heart health and brain function. They also boost immunity and improve skin health due to their high vitamin E, zinc, and magnesium content.","1KG","1000","\"3\" Nums"));
        itemsList.add(new ItemModel(4,"Walnuts",R.drawable.walnut,"Walnuts are packed with omega-3 fatty acids and antioxidants, promoting brain and heart health. They also support weight management and reduce inflammation due to their high fiber and polyphenol content.","1KG","600","\"1\" Nums"));
        itemsList.add(new ItemModel(5,"Fig",R.drawable.figg,"Figs are rich in fiber and natural sugars, aiding digestion and promoting gut health. They also contain antioxidants and essential minerals like calcium and potassium, supporting bone health and overall immunity.","1KG","650","\"5\" Nums"));
        itemsList.add(new ItemModel(6,"Kiwi",R.drawable.kiwi,"Kiwi is rich in vitamin C and antioxidants, boosting immunity and promoting healthy skin. It also aids digestion and heart health due to its high fiber and potassium content.","1KG","700","\"3\" Nums"));
        itemsList.add(new ItemModel(7,"Black Grapes",R.drawable.blackgrapes,"Dry black grapes are rich in antioxidants and iron, helping to improve blood circulation and prevent anemia. They also support heart health and digestion due to their high fiber and natural resveratrol content.","1KG","300","\"6\" Nums"));
        itemsList.add(new ItemModel(8,"Yellow Grapes",R.drawable.yellowgrapes,"Yellow grapes are rich in antioxidants and vitamin C, boosting immunity and skin health. They also support heart health and digestion due to their high fiber and potassium content.","1KG","500","\"6\" Nums"));
        itemsList.add(new ItemModel(9,"Mabroom Dates",R.drawable.mabroomdates,"Mabroom dates are rich in natural sugars and fiber, providing sustained energy and aiding digestion. They also contain essential minerals like potassium and magnesium, supporting heart health and overall well-being.","1KG","600","\"3\" Nums"));
        itemsList.add(new ItemModel(10,"Black Dates",R.drawable.blackdates,"Black dates are rich in fiber and natural sugars, promoting digestion and providing instant energy. They also contain essential minerals like iron and potassium, supporting heart health and boosting immunity.","1KG","500","\"5\" Nums"));
        itemsList.add(new ItemModel(11,"Pumpkin Seeds",R.drawable.pumpkingseeds,"Pumpkin seeds are rich in magnesium, zinc, and antioxidants, supporting heart health and boosting immunity. They also promote better sleep and digestion due to their high fiber and tryptophan content.","1KG","500","\"1\"0 Nums"));
        itemsList.add(new ItemModel(12,"Brazil Nuts",R.drawable.brazilnuts,"Brazil nuts are packed with selenium, supporting immune function and thyroid health. They also contain healthy fats and antioxidants, promoting heart health and reducing inflammation.","1KG","1500","\"5\" Nums"));
        itemsList.add(new ItemModel(13,"Hazel Nuts",R.drawable.hazelenuts,"Hazelnuts are rich in healthy fats, vitamins, and antioxidants, promoting heart health and reducing inflammation. They also support brain function and improve skin health due to their high vitamin E content.","1KG","800","\"5\" Nums"));
        itemsList.add(new ItemModel(14,"Deluxe Pecans",R.drawable.deluxepecansapp,"Deluxe pecans are rich in healthy monounsaturated fats and antioxidants, supporting heart health and reducing inflammation. They also aid in weight management and promote brain function due to their high fiber and vitamin E content.","1KG","2500","\"5\" Nums"));
        itemsList.add(new ItemModel(15,"Dry Mango",R.drawable.drymangoapp,"Dry mango is rich in vitamins A and C, supporting immunity and promoting healthy skin. It also provides fiber, aiding digestion and helping maintain a healthy digestive system.","1KG","200","\"3\" Nums"));
        itemsList.add(new ItemModel(16,"Makhana Plain",R.drawable.makhanaplainapp,"Plain makhana (fox nuts) are rich in protein, fiber, and antioxidants, promoting digestion and weight management. They also support heart health and improve bone strength due to their high calcium and magnesium content.","1KG","400","\"1\"0 Nums"));
        itemsList.add(new ItemModel(17,"Turkish Apricot",R.drawable.turkishapricotapp,"Turkish apricots are rich in vitamins A and C, supporting healthy skin and boosting immunity. They also provide fiber and potassium, promoting digestion and supporting heart health.","1KG","1000","\"4\" Nums"));
        itemsList.add(new ItemModel(18,"Tutti Frutti",R.drawable.tuttifruttiapp,"Tutti frutti is a mix of dried fruits that provides vitamins and antioxidants, supporting immunity and promoting skin health. It also offers fiber, aiding digestion and helping maintain gut health.","1KG","200","\"10\" Nums"));
        itemsList.add(new ItemModel(19,"Dry Fig",R.drawable.dryfig,"Dry figs are rich in fiber and natural sugars, promoting digestive health and providing sustained energy. They also contain essential minerals like calcium and iron, supporting bone health and preventing anemia.","1KG","700","\"5\" Nums"));
        itemsList.add(new ItemModel(20,"Mixed Fruit & Nuts",R.drawable.mixed,"Mixed dry fruits and nuts are packed with essential vitamins, minerals, and healthy fats, supporting heart health and boosting immunity. They also provide fiber and antioxidants, promoting digestion and reducing inflammation.","1KG","700","\"10\" Nums"));

        SharedPreferences sh = getSharedPreferences("item", Context.MODE_PRIVATE);

        int itemId = sh.getInt("ItemId",0);

        //Toast.makeText(this, "Item Id is "+itemId, Toast.LENGTH_SHORT).show();


        itmName.setText(itemsList.get(itemId).getItemName());
        itmImage.setImageResource(itemsList.get(itemId).getItemImage());
        itmDesc.setText(itemsList.get(itemId).getItemDescription());
        String priceUOM = itemsList.get(itemId).getPrice()+" - "+itemsList.get(itemId).getItemUOM();
        itmPrice.setText(priceUOM);
        itmNums.setText("Daily ".concat(itemsList.get(itemId).getNums()));

        SharedPreferences preferences= getSharedPreferences("itemDetail",MODE_PRIVATE);
        SharedPreferences.Editor editor=preferences.edit();

        buy_now.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                editor.putString("ItemName",itemsList.get(itemId).getItemName());
                editor.putString("ItemPrice",itemsList.get(itemId).getPrice());
                editor.apply();
                Intent i1 = new Intent(OneProductViewActivity.this, ActivityPaymentSummary.class);
                startActivity(i1);
            }
        });

        arrow3=(ImageView) findViewById(R.id.arrow3);

        arrow3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(OneProductViewActivity.this,ProductListActivity.class);
                startActivity(it);
                finish();
            }
        });
    }
}