package com.futogen.natureharvest;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;

public class ProductListActivity extends AppCompatActivity {
    LinearLayout bl1,pl1,cl1,wl1,fl1,kl1,bgl1,ygl1,mdl1,bdl1,psl1,bnl1,hnl1,depel1,dml1,khal1,tal1,tutifl1,dfl1,mfnl1;

    TextView signOut,userName;

    public FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_product_list);
        bl1=findViewById(R.id.bl);
        pl1=findViewById(R.id.pl);
        cl1=findViewById(R.id.cl);
        wl1=findViewById(R.id.wl);
        fl1=findViewById(R.id.fl);
        kl1=findViewById(R.id.kl);
        bgl1=findViewById(R.id.bgl);
        ygl1=findViewById(R.id.ygl);
        mdl1=findViewById(R.id.mdl);
        bdl1=findViewById(R.id.bdl);
        psl1=findViewById(R.id.psl);
        bnl1=findViewById(R.id.bnl);
        hnl1=findViewById(R.id.hnl);
        depel1=findViewById(R.id.depel);
        dml1=findViewById(R.id.dml);
        khal1=findViewById(R.id.khal);
        tal1=findViewById(R.id.tal);
        tutifl1=findViewById(R.id.tutifl);
        dfl1=findViewById(R.id.dfl);
        mfnl1=findViewById(R.id.mfnl);

        signOut=(TextView)findViewById(R.id.signOutTV);
        userName=(TextView)findViewById(R.id.userNameTV);

        fAuth = FirebaseAuth.getInstance();

        userName.setText("Welcome, ".concat(fAuth.getCurrentUser().getEmail().toString()));
        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fAuth.signOut();
                Intent i1=new Intent(ProductListActivity.this,MainActivity.class);
                startActivity(i1);
                finish();
            }
        });

        SharedPreferences preferences= getSharedPreferences("item",MODE_PRIVATE);
        SharedPreferences.Editor editor=preferences.edit();

        bl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",0);
                editor.commit();
                Intent ii1=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii1);
            }
        });
        pl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",1);
                editor.commit();
                Intent ii2=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii2);
            }
        });
        cl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",2);
                editor.commit();
                Intent ii3=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii3);
            }
        });
        wl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",3);
                editor.commit();
                Intent ii4=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii4);
            }
        });
        fl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",4);
                editor.commit();
                Intent ii5=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii5);
            }
        });
        kl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",5);
                editor.commit();
                Intent ii6=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii6);
            }
        });
        bgl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",6);
                editor.commit();
                Intent ii7=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii7);
            }
        });
        ygl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",7);
                editor.commit();
                Intent ii8=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii8);
            }
        });
        mdl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",8);
                editor.commit();
                Intent ii9=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii9);
            }
        });
        bdl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",9);
                editor.commit();
                Intent ii10=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii10);
            }
        });
        psl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",10);
                editor.commit();
                Intent ii11=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii11);
            }
        });
        bnl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",11);
                editor.commit();
                Intent ii12=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii12);
            }
        });
        hnl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",12);
                editor.commit();
                Intent ii13=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii13);
            }
        });
        depel1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",13);
                editor.commit();
                Intent ii14=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii14);
            }
        });
        dml1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",14);
                editor.commit();
                Intent ii15=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii15);
            }
        });
        khal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",15);
                editor.commit();
                Intent ii16=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii16);
            }
        });
        tal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",16);
                editor.commit();
                Intent ii17=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii17);
            }
        });
        tutifl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",17);
                editor.commit();
                Intent ii18=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii18);
            }
        });
        dfl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",18);
                editor.commit();
                Intent ii19=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii19);
            }
        });
        mfnl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putInt("ItemId",19);
                editor.commit();
                Intent ii20=new Intent(ProductListActivity.this,OneProductViewActivity.class);
                startActivity(ii20);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }

    /*@Override
    public void onBackPressed() {
        super.onBackPressed();
        finishAffinity(); // Closes the activity and its stack
    }*/


}